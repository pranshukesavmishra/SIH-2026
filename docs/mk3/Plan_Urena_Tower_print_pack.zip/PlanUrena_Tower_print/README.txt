Plan Urena MK3 TOWER print pack (Team ZeroDrift)

Six parts + a test coupon. PETG, 0.2 mm layers, 4 walls, 25% infill.
Print 00_test_coupon first (about an hour). If every fit is right, print the rest.

  01_tripod_base   x1   flat
  02_tower_sleeve  x1   foot flange on the bed
  03_tower_cap     x1   flat
  04_pan_hub       x1   small end down
  05_tilt_mount    x1   plate down
  06_head          x1   stand on the clamp rear, laser tube up; supports only under the camera plate

STL = print files (each already lying in its print orientation). STEP = the same parts for editing.
Total 198 g for the six parts. Sizes in mm. Clearance checked for pan +/-90 and tilt +/-45.

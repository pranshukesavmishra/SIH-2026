Plan Urena print pack (Team ZeroDrift)
=====================================
1_PRINT_FIRST/00_test_coupon.stl   print this first; we check the fits
2_STL/                             every part, already placed flat on the bed (print these)
3_STEP/                            the same parts as STEP, only for editing
Plan_Urena_print_shop.pdf          settings and the parts list with pictures

Settings: PETG, 0.2 mm layers, 0.4 mm nozzle, 4 walls, 5 top/bottom, 40 % gyroid.
Supports: none, except inside the motor pocket of 01_base_hub. Brim on 01_base_hub and 16_electronics_box.
Black: 11_head, 12_front_plate, 13_laser_holder. Scale 100 %, do not rescale.
Print 02_leg_1, 02_leg_2, 02_leg_3 (three legs). Everything else: one each (04_magnet_cap: two if easy).
